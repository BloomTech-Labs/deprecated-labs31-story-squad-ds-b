Thanks for downloading!
===============================================================
This DEMO FONT is for PERSONAL USE ONLY!
===============================================================

By installing or using this font, you are agree to the Product Usage Agreement:

1. This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

2. You are requires a license for PROMOTIONAL or COMMERCIAL use.

3. CONTACT ME before any Promotional or Commercial Use!

EMAIL SUPPORT:
rismanginarwan8@gmail.com
support@garisman.com

===============================================================

COMMERCIAL LICENSE:

http://www.garisman.com

https://creativemarket.com/Garisman?u=Garisman

===============================================================

Paypal account for donation : https://paypal.me/rginarwan/

===============================================================

NOTE:
- If there is a problem, question, or anything about my fonts, please sent an email to: support@garisman.com


- Share your work with this font and tag us on instagram @grsmn.id #grsmnid

================
Best Regards,
Garisman Studio