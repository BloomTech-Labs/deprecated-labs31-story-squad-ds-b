NOTE: This font is FREE FOR PERSONAL USE! 
But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/JefriDwiAlfatah

Please visit our store for more premium fonts : 
https://www.creativefabrica.com/designer/bluestype-studio/
https://fontbundles.net/bluestype-studio

Thank You.

INDONESIA - MOHON DIBACA:
Halo, buat agency, designer, youtuber, atau siapa saja yang ingin menggunakan
font ini untuk kebutuhan KOMERSIL seperti poster filem, pamflet promo, logo perusahaan, kaos,
dan sejenisnya bisa langsung membeli lisensinya di saya,
silahkan hubungi email saya di jefri.dwi333@gmail.com
TENANG, harga bersahabat kok :)

NOTE: Menggunakan font milik Bluestype tanpa izin untuk kebutuhan komersil akan dikenakan denda minimal $1000 atau Rp 15.000.000

Terima kasih
